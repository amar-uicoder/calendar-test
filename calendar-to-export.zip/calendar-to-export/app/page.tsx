import Calendar from "./component/calendar/calendar"
export default function Page() {
  return <Calendar/>
}